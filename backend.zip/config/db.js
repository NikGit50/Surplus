const mongoose = require('mongoose');

let mongod = null;

const connectDB = async () => {
  const uri =
    process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/surplus_to_shelter';

  try {
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 2500,
    });
    console.log(`🔌 MongoDB Connected to: ${mongoose.connection.host}`);
  } catch (err) {
    console.warn(`⚠️ Primary MongoDB unavailable: ${err.message}`);
    console.log('Skipping database fallback to keep the server alive.');
  }
};

module.exports = connectDB;
